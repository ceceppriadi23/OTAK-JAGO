# OTAK JAGO — MYSTERY QUEST V3

Versi V3 memakai applicationId `com.otakjago.mysteryquest.v3`, versionCode 3, versionName 1.1.0.

GitHub Actions menghasilkan **OTAK-JAGO-V3.apk** dan artifact **OTAK-JAGO-V3-APK**.
