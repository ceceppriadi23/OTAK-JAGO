package com.otakjago.mysteryquest.v3

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(8, 17, 38)
    private val panel = Color.rgb(24, 34, 58)
    private val gold = Color.rgb(255, 183, 0)
    private var content: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(bg)
        }
        val top = TextView(this).apply {
            text = "🧠 OTAK JAGO   ⭐ 0   🪙 100   ❤️ 5"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 18)
        }
        root.addView(top)
        val h = TextView(this).apply {
            text = title
            textSize = 30f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(4, 8, 4, 18)
        }
        root.addView(h)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("⌂ HOME","🗺 MAP","🎁 REWARD","👤 PROFILE").forEach { label ->
            nav.addView(Button(this).apply {
                text = label
                setOnClickListener { Toast.makeText(this@MainActivity, "Menu $label", Toast.LENGTH_SHORT).show() }
            }, LinearLayout.LayoutParams(0, 58, 1f))
        }
        root.addView(nav)
        return root
    }

    private fun card(text: String, sub: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = "$text\n$sub"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(panel)
            setOnClickListener { action() }
        }
        content?.addView(b, LinearLayout.LayoutParams(-1, 105).apply { setMargins(0, 8, 0, 8) })
    }

    private fun showHome() {
        val root = base("Seberapa Jago Otakmu?")
        val intro = TextView(this).apply {
            text = "Petualangan dimulai dari pikiranmu. Selesaikan puzzle untuk membuka dunia baru!"
            textSize = 18f; setTextColor(Color.LTGRAY); setPadding(5, 0, 5, 18)
        }
        content?.addView(intro)
        card("🔎 Cari Perbedaan", "10 level • 5 perbedaan", { differenceGame() })
        card("🧩 Tebak Kata", "20 teka-teki", { wordGame() })
        card("🧠 Teka-Teki Logika", "20 pertanyaan", { logicGame() })
        card("🔥 Tantangan Harian", "Bonus koin", { dailyGame() })
        card("🗺 Petualangan", "Hutan Misterius • Dunia 1", { Toast.makeText(this, "Dunia 1 segera dimulai!", Toast.LENGTH_SHORT).show() })
        setContentView(root)
    }

    private fun gameScreen(title: String, question: String, answers: List<String>, correct: Int) {
        val root = base(title)
        content?.addView(TextView(this).apply {
            text = "OTI 🦉\n\n$question"
            textSize = 22f; setTextColor(Color.WHITE); setPadding(6, 8, 6, 24)
        })
        answers.forEachIndexed { i, a ->
            card(a, "Pilih jawaban", {
                if (i == correct) {
                    Toast.makeText(this, "🎉 BENAR! +10 XP", Toast.LENGTH_SHORT).show()
                    showHome()
                } else Toast.makeText(this, "❌ Belum tepat. Coba lagi!", Toast.LENGTH_SHORT).show()
            })
        }
        card("↩ Kembali", "Ke menu utama", { showHome() })
        setContentView(root)
    }

    private fun differenceGame() = gameScreen("🔎 Cari Perbedaan", "Ada 5 perbedaan. Pilih lokasi yang benar!", listOf("🏠 Atap rumah", "🌳 Pohon kiri", "☀️ Matahari", "🚪 Pintu"), 1)
    private fun wordGame() = gameScreen("🧩 Tebak Kata", "Aku punya sayap tetapi bukan burung. Siapakah aku?", listOf("Pesawat", "Ikan", "Kucing", "Pohon"), 0)
    private fun logicGame() = gameScreen("🧠 Teka-Teki Logika", "Angka berikutnya: 2, 4, 8, 16, ...", listOf("20", "24", "32", "64"), 2)
    private fun dailyGame() = gameScreen("🔥 Tantangan Harian", "Jika hari ini Senin, 3 hari lagi hari apa?", listOf("Selasa", "Rabu", "Kamis", "Jumat"), 2)
}
