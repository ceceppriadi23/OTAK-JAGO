# OTAK JAGO — MYSTERY QUEST V1

Fondasi game Android ringan bertema **asah otak + adventure**.

## Sudah tersedia
- Home screen
- 4 menu puzzle yang dapat dibuka
- Cari Perbedaan
- Tebak Kata
- Teka-Teki Logika
- Tantangan Harian
- Jawaban benar/salah
- XP sederhana
- Karakter pendamping OTI
- Navigasi kembali ke Home
- Mode portrait/offline

## Build APK via GitHub
1. Upload seluruh isi folder ini ke repository GitHub.
2. Masuk **Actions**.
3. Pilih **Build OTAK JAGO Mystery Quest APK**.
4. Tekan **Run workflow**.
5. Setelah selesai dan status hijau, buka hasil run.
6. Scroll ke **Artifacts**.
7. Download **OTAK-JAGO-MYSTERY-QUEST**.

Workflow memakai Gradle yang tersedia di runner GitHub, jadi tidak membutuhkan file `gradlew`.

## Tahap berikutnya
Setelah APK V1 terbukti jalan:
- visual puzzle sungguhan
- karakter OTI
- BGM dan SFX
- sistem level
- map adventure
- coin/heart
- penyimpanan progress
- database puzzle
- 10 dunia adventure

Jaga ukuran APK tetap kecil pada tahap awal.
