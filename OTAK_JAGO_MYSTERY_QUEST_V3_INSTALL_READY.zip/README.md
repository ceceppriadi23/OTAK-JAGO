# OTAK-JAGO Mystery Quest V3

Install-ready Android build configuration.

## V3 changes
- New application ID: `com.otakjago.mysteryquest.v3`
- Version code: `3`
- Version name: `1.1.0`
- Debug APK is renamed to `OTAK-JAGO-V3.apk`
- GitHub Actions produces the APK directly as an artifact.

The new application ID is intentional so V3 can be installed separately from the older V2 APK and avoids signature/package conflicts with the old installation.
