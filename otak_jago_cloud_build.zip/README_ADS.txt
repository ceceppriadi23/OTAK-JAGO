OTAK JAGO — ADMOB DEVELOPMENT SETUP
====================================
- Google Mobile Ads SDK dependency added.
- Google TEST App ID configured.
- Google TEST rewarded ad unit configured.
- Rewarded ad loader/show method added for +1 life.

IMPORTANT:
Use Google's TEST IDs only during development.
Before release:
1. Create an AdMob app.
2. Replace the test App ID in AndroidManifest.xml.
3. Replace TEST_REWARDED_AD_UNIT in MainActivity.java.
4. Wire the reward callback to the game's JS state so the reward is granted exactly once.
5. Add privacy/consent flow appropriate to your users and region.
6. Test ads on physical devices before production.
