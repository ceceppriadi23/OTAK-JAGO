OTAK JAGO — COMPLETE PROTOTYPE V1
=================================
Sudah mencakup:
- Home UI
- Level map 10 level
- Cari Perbedaan: 10 level, 5 target per level, timer, hint, skip, stars, reward
- Tebak Kata: 10 soal
- Teka-Teki Logika: 10 soal
- Tantangan harian
- Score, coins, lives, streak, mission
- Reward/skip/hint simulation
- LocalStorage persistence
- Responsive mobile layout

STATUS:
Ini adalah prototype web lengkap dan belum merupakan APK signed/AAB produksi.
Untuk produksi Android: bungkus dengan Capacitor/WebView atau port ke native engine, lalu sambungkan Google Mobile Ads SDK (AdMob), billing/in-app purchase, analytics, consent/privacy, dan Play Console.
