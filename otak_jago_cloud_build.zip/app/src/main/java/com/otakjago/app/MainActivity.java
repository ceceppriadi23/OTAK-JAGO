package com.otakjago.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;

    // Google-provided TEST rewarded ad unit. Replace with your production unit before release.
    private static final String TEST_REWARDED_AD_UNIT =
            "ca-app-pub-3940256099942544/5224354917";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MobileAds.initialize(this, status -> loadRewarded());

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF060914);
        webView.setWebViewClient(new WebViewClient());

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private void loadRewarded() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, TEST_REWARDED_AD_UNIT, request,
            new RewardedAdLoadCallback() {
                @Override
                public void onAdLoaded(RewardedAd ad) {
                    rewardedAd = ad;
                }

                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    rewardedAd = null;
                }
            });
    }

    public void showRewardedForLife() {
        if (rewardedAd == null) {
            Toast.makeText(this, "Iklan belum siap. Coba lagi sebentar.", Toast.LENGTH_SHORT).show();
            loadRewarded();
            return;
        }

        rewardedAd.show(this, rewardItem -> {
            // The JS game can be wired to this callback in the next integration step.
            Toast.makeText(this, "+1 ❤️", Toast.LENGTH_SHORT).show();
        });
        rewardedAd = null;
        loadRewarded();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
