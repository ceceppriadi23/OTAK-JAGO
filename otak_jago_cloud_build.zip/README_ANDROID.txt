OTAK JAGO — ANDROID PROJECT
============================
Project ini membungkus game HTML OTAK JAGO Complete V1 ke Android WebView.

Cara membuka:
1. Buka folder ini di Android Studio.
2. Biarkan Gradle melakukan sync.
3. Jalankan pada emulator/HP Android.
4. Build > Generate Signed Bundle / APK untuk membuat APK/AAB.

Catatan:
- Ini belum menyertakan AdMob, billing, analytics, atau signing key.
- INTERNET permission sudah disiapkan untuk integrasi layanan online berikutnya.
- Package: com.otakjago.app
- Version: 1.0.0
